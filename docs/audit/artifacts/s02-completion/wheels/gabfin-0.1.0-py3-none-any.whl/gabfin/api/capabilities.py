"""Deterministic capability ceilings; principals must originate from trusted stores."""
from gabfin.contracts.identity import Capability as C,Role,Principal,Resource
CHAT={C.READ_ACCOUNT,C.RESOLVE_SYMBOLS,C.START_RESEARCH,C.READ_REPORT,C.DRAFT_TRADE_PLAN}
CEILINGS={Role.CHAT:CHAT,Role.RESEARCH:CHAT|{C.READ_MARKET,C.PROPOSE_STRATEGY},Role.STRATEGY:{C.READ_MARKET,C.READ_ACCOUNT,C.EMIT_STRATEGY_INTENT},Role.EXECUTOR:{C.READ_MARKET,C.READ_ACCOUNT,C.SUBMIT_ORDER,C.CANCEL_ORDER},Role.OWNER:set(C)-{C.SUBMIT_ORDER,C.EMIT_STRATEGY_INTENT}}
def authorize(principal:Principal,capability:C,resource:Resource)->None:
    if capability not in CEILINGS[principal.role] or capability not in principal.scope or resource.owner!=principal.actor_id:
        raise PermissionError('Forbidden')
